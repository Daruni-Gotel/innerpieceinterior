/**
 * BeforeAfterSlider — Pacific Modernism design system
 * A drag-to-reveal comparison slider for before/after project photography.
 * Uses clipPath on the before image so dragging always works correctly.
 * Warm bronze accent on the handle, clean architectural divider line.
 */
import { useRef, useState, useCallback, useEffect } from "react";

interface BeforeAfterSliderProps {
  beforeSrc: string;
  afterSrc: string;
  beforeLabel?: string;
  afterLabel?: string;
  className?: string;
}

export default function BeforeAfterSlider({
  beforeSrc,
  afterSrc,
  beforeLabel = "Before",
  afterLabel = "After",
  className = "",
}: BeforeAfterSliderProps) {
  const [position, setPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const pct = Math.min(Math.max((x / rect.width) * 100, 1), 99);
    setPosition(pct);
  }, []);

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  // Also allow clicking anywhere on the container to jump the slider
  const onContainerMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    updatePosition(e.clientX);
  }, [updatePosition]);

  useEffect(() => {
    if (!isDragging) return;
    const onMouseMove = (e: MouseEvent) => updatePosition(e.clientX);
    const onTouchMove = (e: TouchEvent) => {
      if (e.touches[0]) updatePosition(e.touches[0].clientX);
    };
    const onUp = () => setIsDragging(false);

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("touchmove", onTouchMove, { passive: true });
    window.addEventListener("touchend", onUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("touchend", onUp);
    };
  }, [isDragging, updatePosition]);

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden select-none bg-[#f0ebe4] ${className}`}
      style={{ touchAction: "none", cursor: isDragging ? "col-resize" : "col-resize" }}
      onMouseDown={onContainerMouseDown}
    >
      {/* AFTER image — always visible full width */}
      <img
        src={afterSrc}
        alt={afterLabel}
        className="absolute inset-0 w-full h-full object-contain block"
        draggable={false}
      />

      {/* BEFORE image — clipped to left portion using clipPath */}
      <img
        src={beforeSrc}
        alt={beforeLabel}
        className="absolute inset-0 w-full h-full object-contain block"
        style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}
        draggable={false}
      />

      {/* Spacer to give the container natural height */}
      <div className="w-full" style={{ paddingBottom: "75%" }} />

      {/* Divider line */}
      <div
        className="absolute top-0 bottom-0 w-[2px] bg-white shadow-md pointer-events-none"
        style={{ left: `${position}%` }}
      />

      {/* Handle — only this triggers drag, not the whole container */}
      <div
        className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20"
        style={{ left: `${position}%` }}
        onMouseDown={onMouseDown}
        onTouchStart={onTouchStart}
      >
        <div className="w-11 h-11 rounded-full bg-[#2c2420] border-2 border-[#c9a96e] flex items-center justify-center shadow-xl">
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <path d="M8 6L3 11L8 16" stroke="#c9a96e" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M14 6L19 11L14 16" stroke="#c9a96e" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>

      {/* Labels */}
      <div className="absolute top-3 left-3 px-2 py-1 bg-[#2c2420]/75 text-[#f7f3ee] text-[0.65rem] tracking-widest uppercase font-sans pointer-events-none z-10">
        {beforeLabel}
      </div>
      <div className="absolute top-3 right-3 px-2 py-1 bg-[#c9a96e]/90 text-[#2c2420] text-[0.65rem] tracking-widest uppercase font-sans pointer-events-none z-10">
        {afterLabel}
      </div>
    </div>
  );
}
