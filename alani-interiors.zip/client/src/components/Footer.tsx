/*
 * INNERPIECE — Footer Component
 * Design: Pacific Modernism — deep earth background, warm accents
 */

import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-[#1a1612] text-[#f7f3ee]">
      <div className="container py-20">
        {/* Top row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-16">
          {/* Brand */}
          <div>
            <p className="font-display text-2xl mb-2">inner|piece</p>
            <p className="label-text text-[#9a7c5f] mb-6">Interior Design &amp; Architecture</p>
            <p className="font-body text-[0.85rem] text-[rgba(247,243,238,0.55)] leading-relaxed">
              Elevated Island Living, Designed From Within.<br />
              Haiku, North Shore, Maui, Hawai'i.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <p className="label-text text-[#9a7c5f] mb-6">Navigate</p>
            <ul className="flex flex-col gap-3">
              {[
                { href: "/", label: "Home" },
                { href: "/work", label: "Work" },
                { href: "/services", label: "Services" },
                { href: "/brand-foundation", label: "Our Story" },
                { href: "/contact", label: "Contact" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="font-body text-[0.8rem] text-[rgba(247,243,238,0.6)] hover:text-[#9a7c5f] transition-colors duration-300 tracking-wide"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <p className="label-text text-[#9a7c5f] mb-6">Get in Touch</p>
            <div className="flex flex-col gap-3">
              <a
                href="mailto:innerpieceinterior@gmail.com"
                className="font-body text-[0.8rem] text-[rgba(247,243,238,0.6)] hover:text-[#9a7c5f] transition-colors duration-300"
              >
                innerpieceinterior@gmail.com
              </a>
              <a
                href="tel:+18082142058"
                className="font-body text-[0.8rem] text-[rgba(247,243,238,0.6)] hover:text-[#9a7c5f] transition-colors duration-300"
              >
                808 · 214 · 2058
              </a>
              <div className="flex gap-5 mt-4">
                <a
                  href="https://www.instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="label-text text-[rgba(247,243,238,0.4)] hover:text-[#9a7c5f] transition-colors"
                >
                  Instagram
                </a>
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="label-text text-[rgba(247,243,238,0.4)] hover:text-[#9a7c5f] transition-colors"
                >
                  LinkedIn
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-[rgba(247,243,238,0.1)] pt-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <p className="font-body text-[0.7rem] text-[rgba(247,243,238,0.3)] tracking-wide">
            © {new Date().getFullYear()} Innerpiece Interior Design and Architecture LLC. All rights reserved.
          </p>
          <p className="font-accent italic text-[0.85rem] text-[rgba(247,243,238,0.3)]">
            With Aloha.
          </p>
        </div>
      </div>
    </footer>
  );
}
