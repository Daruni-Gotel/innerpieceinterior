/*
 * INNERPIECE — Navigation Component
 * Design: Pacific Modernism — minimal, architectural, warm
 * Sticky top nav with transparent-to-solid scroll behavior
 */

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";

const navLinks = [
  { href: "/work", label: "Work" },
  { href: "/services", label: "Services" },
  { href: "/brand-foundation", label: "Our Story" },
  { href: "/contact", label: "Contact" },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  // Only the homepage hero gets the transparent/light nav treatment
  const isHomePage = location === "/";
  const isLight = isHomePage && !scrolled;

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isLight
            ? "bg-transparent"
            : "bg-[#f7f3ee] border-b border-[#d4c4b0]"
        }`}
      >
        <div className="container flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/logo2025_c29eb14a.jpg"
              alt="Innerpiece logo"
              className="h-12 w-auto object-contain rounded-sm"
            />
            <div className="flex flex-col items-start gap-0">
              <span
                className={`font-display text-[1.1rem] tracking-[0.08em] transition-colors duration-300 ${
                  isLight ? "text-[#faf8f5]" : "text-[#2c2420]"
                }`}
              >
                inner|piece
              </span>
              <span
                className={`font-body text-[0.55rem] tracking-[0.22em] uppercase transition-colors duration-300 ${
                  isLight ? "text-[rgba(250,248,245,0.6)]" : "text-[#9a7c5f]"
                }`}
              >
                Interior Design &amp; Architecture
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`font-body text-[0.7rem] tracking-[0.18em] uppercase transition-colors duration-300 ${
                  location === link.href
                    ? isLight
                      ? "text-[#faf8f5]"
                      : "text-[#9a7c5f]"
                    : isLight
                    ? "text-[rgba(250,248,245,0.75)] hover:text-[#faf8f5]"
                    : "text-[#2c2420] hover:text-[#9a7c5f]"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <a
              href="https://calendly.com/daruniinnerpiece/30min"
              target="_blank"
              rel="noopener noreferrer"
              className={`font-body text-[0.7rem] tracking-[0.18em] uppercase px-5 py-2.5 border transition-all duration-300 ${
                isLight
                  ? "border-[rgba(250,248,245,0.5)] text-[#faf8f5] hover:bg-[rgba(250,248,245,0.1)]"
                  : "border-[#2c2420] text-[#2c2420] hover:bg-[#2c2420] hover:text-[#faf8f5]"
              }`}
            >
              Strategy Session
            </a>
          </div>

          {/* Mobile Hamburger */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className={`md:hidden flex flex-col gap-1.5 p-2 transition-colors duration-300 ${
              isLight ? "text-[#faf8f5]" : "text-[#2c2420]"
            }`}
            aria-label="Toggle menu"
          >
            <span
              className={`block w-6 h-px transition-all duration-300 bg-current ${
                menuOpen ? "rotate-45 translate-y-[7px]" : ""
              }`}
            />
            <span
              className={`block w-6 h-px transition-all duration-300 bg-current ${
                menuOpen ? "opacity-0" : ""
              }`}
            />
            <span
              className={`block w-6 h-px transition-all duration-300 bg-current ${
                menuOpen ? "-rotate-45 -translate-y-[7px]" : ""
              }`}
            />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 z-40 bg-[#1a1612] flex flex-col justify-center items-center transition-all duration-500 ${
          menuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <div className="flex flex-col items-center gap-8">
          {navLinks.map((link, i) => (
            <Link
              key={link.href}
              href={link.href}
              className="font-display text-3xl text-[#f7f3ee] hover:text-[#9a7c5f] transition-colors duration-300"
              style={{ animationDelay: `${i * 0.07}s` }}
            >
              {link.label}
            </Link>
          ))}
          <a
            href="https://calendly.com/daruniinnerpiece/30min"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 btn-outline-light text-sm"
          >
            Book a Strategy Session
          </a>
        </div>
        <div className="absolute bottom-12 flex gap-6">
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="font-body text-[0.65rem] tracking-[0.2em] uppercase text-[rgba(250,248,245,0.5)] hover:text-[#9a7c5f] transition-colors"
          >
            Instagram
          </a>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            className="font-body text-[0.65rem] tracking-[0.2em] uppercase text-[rgba(250,248,245,0.5)] hover:text-[#9a7c5f] transition-colors"
          >
            LinkedIn
          </a>
        </div>
      </div>
    </>
  );
}
