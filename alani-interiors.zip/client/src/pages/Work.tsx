/*
 * INNERPIECE — Work / Portfolio Page
 * Design: Pacific Modernism — editorial grid, asymmetric layouts
 * Palette: Parchment bg, Charcoal text, Bronze accent
 */

import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hero-real_e8aec7f9.png";
const RENDER_AERIAL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/render-aerial_b2dfbeb1.png";
const RENDER_KITCHEN_DINING = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/3d-kitchen-dining_49097972.jpeg";
const RENDER_KITCHEN_ISLAND = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/3d-kitchen-island_7d568245.jpeg";
const RENDER_HOME_OFFICE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/3d-home-office_44125bdb.jpeg";
const RENDER_BEDROOM = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/3d-bedroom_c439c6d4.jpeg";
const RENDER_POOL_OUTDOOR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/3d-pool-outdoor_b24e3cc8.jpeg";
const VIZ_2D_BEDROOM_PALETTE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/2d-bedroom-palette_93aac361.jpeg";
const VIZ_2D_READPDF1 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/2d-readpdf1-1_b77fd427.png";
const LAPRADE_PDF1 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/laprade1-1_c312c9a2.png";
const LAPRADE_PDF2 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/laprade2-1_66949d6d.png";
const UPCOUNTRY_LIVING = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/upcountry-living_0ec5d1b4.png";
const UPCOUNTRY_KITCHEN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/upcountry-kitchen-hires_57198e85.jpeg";
const HAIKU_HOME = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/haiku-home_63d6b2ee.jpeg";
const THAI_BISTRO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/thai-bistro_cc52fdbb.png";
const MTB_DINING1 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/mtb_dining1_8712f524.jpg";
const MTB_DINING2 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/mtb_dining2_aa3fe58f.jpg";
const MTB3 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/mtb3_14b7c287.jpg";
const MTB4 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/mtb4_d8d2df48.jpg";
const MTB5 = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/mtb5_00d9652d.jpg";
const HOOLAWA_BOUTIQUE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hoolawa-concept-1_c6f1d08d.png";
const HAILEMAILE_LIVING = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hailemaile-living_0b802aa6.jpeg";
const CAD_RESTAURANT = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/cad-restaurant-floorplan_0413a9c3.png";
const CAD_2D_FIRSTFLOOR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/cad-2d-firstfloor-1_18cb0a82.png";
const CAD_3D_FIRSTFLOOR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/cad-3d-firstfloor-1_302f4cca.png";
const CAD_FLOORPLAN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/cad-floorplan_d36b97b9.png";
const CAD_BATHROOM_ELEVATION = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/cad-elevation2-1_4f687c17.png";
const HOOLAWA_DISPLAY = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hoolawa-display_4835f628.png";
const HOOLAWA_OVERVIEW = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hoolawa-overview_4c557f6e.png";
const HOOLAWA_COUNTER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hoolawa-counter_3ef4f378.png";
const HAILEMAILE_MUDROOM_BEFORE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hailemaile-mudroom-before_8eefec60.jpeg";
const HAILEMAILE_MUDROOM_AFTER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hailemaile-mudroom-after_e6e88e4d.jpeg";
const HOOLAWA_3D = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hoolawa-3d-layout_ffd2370a.png";
const POWDER_ROOM_CONCEPT_BOARD = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/powder-concept-hires-1_683b2067.png";
const POWDER_ROOM_BEFORE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/powder-room-before_ad470b7c.jpeg";
const POWDER_ROOM_AFTER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/powder-room-after_ed43a11a.jpeg";
const TRANSITIONAL_PR_BEFORE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/IMG_9661_8e08c74f.jpeg";
const TRANSITIONAL_PR_AFTER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/IMG_6263_f12784c6.jpeg";

const projects = [
  {
    id: 11,
    title: "The Wailea Modern",
    category: "Residential",
    type: "Full Interior Design",
    location: "Wailea, Maui",
    year: "2024",
    img: HERO_IMG,
    size: "large",
    description: "This ocean-facing Wailea residence was designed to capture the ease and luminosity of modern island living. A refined Wailea home designed around ocean views, warm neutral tones, and architectural precision — full FF&E selection, spatial planning, and installation, elevated island contemporary at its finest.",
  },
  {
    id: 5,
    title: "Powder Room Remodel",
    category: "Residential",
    type: "Before & After Transformation",
    location: "Maui, Hawai'i",
    year: "2024",
    img: POWDER_ROOM_AFTER,
    beforeImg: POWDER_ROOM_BEFORE,
    afterImg: POWDER_ROOM_AFTER,
    conceptBoard: POWDER_ROOM_CONCEPT_BOARD,
    size: "large",
    description: "A complete powder room transformation — woven rattan mirror, brushed brass fixtures, sconce lighting, and natural woven baskets replace a dated interior with warm, elevated island character.",
  },
  {
    id: 1,
    title: "Hailemaile Haven",
    category: "Residential",
    type: "Full Interior Design",
    location: "Ha'ikū, Maui",
    year: "2024",
    img: UPCOUNTRY_KITCHEN,
    images: [UPCOUNTRY_KITCHEN, HAILEMAILE_LIVING],
    size: "large",
    description: "A custom Hali'imaile home transformed through bold teal cabinetry, statement pendant lighting, and considered materiality — where island character meets architectural precision.",
  },
  {
    id: 10,
    title: "Hali'imaile — Mudroom Transformation",
    category: "Residential",
    type: "Before & After Transformation",
    location: "Hali'imaile, Maui",
    year: "2024",
    img: HAILEMAILE_MUDROOM_AFTER,
    beforeImg: HAILEMAILE_MUDROOM_BEFORE,
    afterImg: HAILEMAILE_MUDROOM_AFTER,
    size: "medium",
    description: "A mudroom entry transformed from a bare builder-grade space into a warm, considered arrival — custom cabinetry, a sculptural woven pendant, and a cushioned bench seat with island-inspired textiles.",
  },
  {
    id: 2,
    title: "Haiku Home",
    category: "Residential",
    type: "Full Interior Design",
    location: "Haiku, Maui",
    year: "2023",
    img: HAIKU_HOME,
    size: "large",
    description: "A warm, eclectic Haiku residence where rich koa hardwood floors, a classic Eames lounge chair, and lush tropical views through every window create a home that feels both grounded and alive.",
  },
  {
    id: 13,
    title: "Transitional Powder Room Remodel",
    category: "Residential",
    type: "Before & After Transformation",
    location: "Maui, Hawai'i",
    year: "2024",
    img: TRANSITIONAL_PR_AFTER,
    beforeImg: TRANSITIONAL_PR_BEFORE,
    afterImg: TRANSITIONAL_PR_AFTER,
    size: "large",
    description: "A transitional powder room transformation — ornate marble sculpture sink and dated gold fixtures give way to a crisp white vanity, hand-painted blue vessel sink, brushed brass wall faucet, and dramatic botanical wallpaper for a fresh, refined character.",
  },
  {
    id: 3,
    title: "Maui Thai Bistro",
    category: "Commercial",
    type: "Award-Winning Restaurant Design",
    location: "Maui, Hawai'i",
    year: "2023",
    img: THAI_BISTRO,
    images: [THAI_BISTRO, MTB_DINING1, MTB_DINING2, MTB3, MTB4, MTB5],
    size: "large",
    description: "An award-winning restaurant redesign — a warm, modern dining environment with Brazilian hardwood as the centrepiece, seating 122 covers across a thoughtfully zoned floor plan.",
  },
  {
    id: 4,
    title: "Ho'olawa Boutique",
    category: "Retail",
    type: "Retail Design & Concept",
    location: "Maui, Hawai'i",
    year: "2023",
    img: HOOLAWA_BOUTIQUE,
    images: [HOOLAWA_BOUTIQUE, HOOLAWA_COUNTER, HOOLAWA_DISPLAY, HOOLAWA_OVERVIEW, HOOLAWA_3D],
    size: "large",
    containImage: true,
    description: "A full interior concept for Ho'olawa Napili — a Maui boutique designed around natural wood panelling, vintage Hawaiian accent decor, and accent lighting that creates distinct focal points throughout the store for a warm, cohesive brand experience.",
  },
  {
    id: 8,
    title: "Technical CAD Drafting Suite",
    category: "Technical",
    type: "CAD Drafting & Floor Plans",
    location: "",
    year: "2022–2024",
    img: CAD_FLOORPLAN,
    images: [CAD_FLOORPLAN, CAD_2D_FIRSTFLOOR, CAD_3D_FIRSTFLOOR, CAD_RESTAURANT, CAD_BATHROOM_ELEVATION],
    containImage: true,
    size: "medium",
    description: "Detailed CAD floor plans, electrical layouts, lighting/RCP plans, and 3D rendered floor plans — the technical backbone of every Innerpiece project, produced to the highest professional standard.",
  },
  {
    id: 6,
    title: "3D Visualization Tools",
    category: "Technical",
    type: "3D Rendering & Spatial Planning",
    location: "",
    year: "2024",
    img: RENDER_AERIAL,
    images: [RENDER_AERIAL, RENDER_KITCHEN_DINING, RENDER_KITCHEN_ISLAND, RENDER_HOME_OFFICE, RENDER_BEDROOM, RENDER_POOL_OUTDOOR],
    containImage: true,
    size: "large",
    description: "A full architectural visualization of a luxury Maui residence — from aerial site rendering to interior kitchen and bedroom views, giving the client a complete picture before a single wall is built.",
  },
  {
    id: 12,
    title: "2D Visualisation Tools",
    category: "Technical",
    type: "2D Visualisation & Concept Design",
    location: "",
    year: "2023–2024",
    img: VIZ_2D_BEDROOM_PALETTE,
    images: [VIZ_2D_BEDROOM_PALETTE, VIZ_2D_READPDF1, LAPRADE_PDF1, LAPRADE_PDF2],
    containImage: true,
    size: "medium",
    description: "Detailed 2D inspiration palettes, material selections, and concept boards that translate design vision into clear, client-ready visual presentations — bridging the gap between concept and construction.",
  },
];

const categories = ["Residential", "Commercial", "Retail", "Technical"];

function ProjectGallery({ images, containImage, size }: { images: string[]; containImage?: boolean; size?: string }) {
  const [idx, setIdx] = useState(0);
  const total = images.length;
  return (
    <div className="relative overflow-hidden">
      <img
        src={images[idx]}
        alt=""
        className={`w-full transition-all duration-500 ${
          containImage ? "object-contain bg-[#f7f3ee]" : "object-cover"
        } ${size === "large" ? "h-[480px]" : "h-[380px]"}`}
      />
      {total > 1 && (
        <>
          {/* Dot indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
            {images.map((_, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  i === idx ? "bg-[#f7f3ee] scale-125" : "bg-[rgba(247,243,238,0.45)]"
                }`}
              />
            ))}
          </div>
          {/* Prev / Next arrows */}
          <button
            onClick={() => setIdx((idx - 1 + total) % total)}
            className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-[rgba(26,22,18,0.55)] hover:bg-[rgba(26,22,18,0.8)] text-[#f7f3ee] rounded-full transition-all duration-200 z-10 text-sm"
          >
            ‹
          </button>
          <button
            onClick={() => setIdx((idx + 1) % total)}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-[rgba(26,22,18,0.55)] hover:bg-[rgba(26,22,18,0.8)] text-[#f7f3ee] rounded-full transition-all duration-200 z-10 text-sm"
          >
            ›
          </button>
        </>
      )}
    </div>
  );
}

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function AnimateSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, inView } = useInView();
  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${
        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
    >
      {children}
    </div>
  );
}

function ProjectCard({ project }: { project: typeof projects[0] }) {
  return (
    <AnimateSection className="group cursor-pointer">
      <div className="relative overflow-hidden img-zoom">
        {(project as any).beforeImg && (project as any).afterImg ? (
          <>
            <BeforeAfterSlider
              beforeSrc={(project as any).beforeImg}
              afterSrc={(project as any).afterImg}
              beforeLabel="Before"
              afterLabel="After"
              className="w-full"
            />
            {(project as any).conceptBoard && (
              <div className="mt-0">
                <img
                  src={(project as any).conceptBoard}
                  alt="Concept Design Board"
                  className="w-full h-auto object-contain bg-[#f7f3ee] block"
                />
                <p className="font-body text-[0.7rem] tracking-[0.18em] uppercase text-[#9a7c5f] text-center py-3 bg-[#f7f3ee]">Concept Design Board</p>
              </div>
            )}
          </>
        ) : (project as any).images ? (
          <ProjectGallery
            images={(project as any).images}
            containImage={(project as any).containImage}
            size={project.size}
          />
        ) : (
          <>
            <img
              src={project.img}
              alt={project.title}
              className={`w-full transition-transform duration-700 group-hover:scale-[1.02] ${
                (project as any).containImage
                  ? "object-contain bg-[#f7f3ee]"
                  : "object-cover"
              } ${
                project.size === "large" ? "h-[480px]" : "h-[380px]"
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[rgba(26,22,18,0.75)] via-[rgba(26,22,18,0.2)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="absolute bottom-0 left-0 right-0 p-7 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500">
              <p className="font-body text-[0.7rem] tracking-[0.18em] uppercase text-[#9a7c5f] mb-2">{project.type}</p>
              <p className="font-display text-xl text-[#f7f3ee]">{project.title}</p>
              <p className="font-body text-[0.8rem] text-[rgba(247,243,238,0.65)] mt-2 leading-relaxed">{project.description}</p>
            </div>
          </>
        )}
      </div>
      <div className="pt-5 pb-2 border-b border-[#d4c4b0]">
        <div className="flex justify-between items-start">
          <div>
            <p className="font-display text-lg text-[#2c2420]">{project.title}</p>
            <p className="font-body text-[0.75rem] text-[#9a7c5f] tracking-wide mt-1">{project.type}{project.location ? ` · ${project.location}` : ""}</p>
          </div>
        </div>
      </div>
    </AnimateSection>
  );
}

function ProjectGrid({ projects: list }: { projects: typeof projects }) {
  // Render projects row by row so "large" cards span 2 cols and the
  // next card always starts on a fresh row — preserving explicit ordering.
  const rows: (typeof projects)[] = [];
  let i = 0;
  while (i < list.length) {
    const p = list[i];
    // Before/after slider cards always get their own full-width row
    const isSlider = !!(p as any).beforeImg;
    if (isSlider || p.size === "large") {
      if (!isSlider && p.size === "large") {
        // Large non-slider card: spans 2 of 3 columns. Pair with the next non-slider card if available.
        const next = list[i + 1];
        if (next && !(next as any).beforeImg) {
          rows.push([p, next]);
          i += 2;
        } else {
          rows.push([p]);
          i += 1;
        }
      } else {
        // Slider card or solo large: always its own row
        rows.push([p]);
        i += 1;
      }
    } else {
      // Medium/small: collect up to 3 per row (never include slider cards)
      const rowItems: typeof projects = [];
      while (i < list.length && list[i].size !== "large" && !(list[i] as any).beforeImg && rowItems.length < 3) {
        rowItems.push(list[i]);
        i++;
      }
      rows.push(rowItems);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      {rows.map((row, ri) => {
        const firstIsLarge = row[0]?.size === "large";
        if (firstIsLarge && row.length === 2) {
          return (
            <div key={ri} className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <ProjectCard project={row[0]} />
              </div>
              <div>
                <ProjectCard project={row[1]} />
              </div>
            </div>
          );
        } else if (firstIsLarge && row.length === 1) {
          return (
            <div key={ri} className="grid grid-cols-1 gap-6">
              <ProjectCard project={row[0]} />
            </div>
          );
        } else {
          // Row of medium/small cards — up to 3 columns
          return (
            <div key={ri} className={`grid grid-cols-1 gap-6 ${
              row.length === 1 ? "md:grid-cols-1" :
              row.length === 2 ? "md:grid-cols-2" :
              "md:grid-cols-3"
            }`}>
              {row.map(p => <ProjectCard key={p.id} project={p} />)}
            </div>
          );
        }
      })}
    </div>
  );
}

export default function Work() {
  const [activeCategory, setActiveCategory] = useState("Residential");

  const filtered = projects.filter(p => p.category === activeCategory);

  return (
    <div className="min-h-screen bg-[#f7f3ee]">
      <Navigation />

      {/* Page Header */}
      <div className="relative pt-40 pb-20 bg-[#2c2420] overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img src={HERO_IMG} alt="" className="w-full h-full object-cover" />
        </div>
        <div className="relative container">
          <AnimateSection>
            <p className="label-text text-[#9a7c5f] mb-4">Portfolio</p>
            <h1 className="font-display text-[clamp(3rem,7vw,6rem)] leading-[1.0] text-[#f7f3ee]">
              Our Work
            </h1>
            <div className="w-16 h-px bg-[#9a7c5f] mt-8 mb-8" />
            <p className="font-body font-light text-[1rem] text-[rgba(247,243,238,0.65)] max-w-xl leading-relaxed">
              A curated selection of residential, commercial, retail, and technical projects across Maui and beyond. Each project is a unique expression of elevated island contemporary design.
            </p>
          </AnimateSection>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="sticky top-20 z-30 bg-[#f7f3ee] border-b border-[#d4c4b0]">
        <div className="container">
          <div className="flex gap-8 py-5 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`font-body text-[0.7rem] tracking-[0.18em] uppercase whitespace-nowrap transition-colors duration-300 pb-1 ${
                  activeCategory === cat
                    ? "text-[#9a7c5f] border-b border-[#9a7c5f]"
                    : "text-[#5a4a3a] hover:text-[#2c2420]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Project Grid */}
      <section className="section-pad">
        <div className="container">
          <ProjectGrid projects={filtered} />
        </div>
      </section>

      {/* CTA */}
      <section className="section-pad bg-[#faf8f5] border-t border-[#d4c4b0]">
        <div className="container text-center">
          <AnimateSection>
            <p className="label-text mb-4">Start Your Project</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#2c2420] mb-6">
              Ready to create something <em>remarkable?</em>
            </h2>
            <p className="font-body font-light text-[1rem] text-[#5a4a3a] max-w-xl mx-auto mb-10 leading-relaxed">
              Every project begins with a conversation. Book a strategy session at $175/hour (30-min minimum) and let's explore what's possible for your space.
            </p>
            <a href="https://calendly.com/daruniinnerpiece/30min" target="_blank" rel="noopener noreferrer" className="btn-primary">
              Book a Strategy Session
            </a>
          </AnimateSection>
        </div>
      </section>

      <Footer />
    </div>
  );
}
