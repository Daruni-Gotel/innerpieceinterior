/*
 * INNERPIECE — Services Page
 * Design: Pacific Modernism — editorial layout, architectural grid
 * All services from Daruni's list, organized into clear categories
 */

import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const SERVICES_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/IMG_2791_4ee8bd55.jpeg";
const KITCHEN_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/daruni-hardhat_b03a2eb4.jpg";
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/daruni-site_54ad9cbf.jpg";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function AnimateSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, inView } = useInView();
  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${
        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
    >
      {children}
    </div>
  );
}

const serviceCategories = [
  {
    id: "01",
    title: "Design & Architecture",
    tagline: "From the ground up.",
    services: [
      { name: "New Build", desc: "Full interior architecture and design for new construction projects — from spatial planning and concept through to FF&E installation." },
      { name: "Full & Partial Renovation / Remodel", desc: "Comprehensive or targeted renovation services, transforming existing spaces with architectural precision and elevated design." },
      { name: "Concept Design", desc: "Sketch ideas, inspiration boards, material and finish selections — bringing your vision into vivid, tangible form." },
      { name: "Spatial Planning", desc: "Optimised floor plan layouts that balance flow, function, and beauty — for both residential and commercial spaces." },
    ],
  },
  {
    id: "02",
    title: "Residential Design",
    tagline: "Spaces that feel like home.",
    services: [
      { name: "Residential Interior Design", desc: "Full-service interior design for luxury homes — from concept to completion, with meticulous attention to every detail." },
      { name: "Interior Decoration & Installation", desc: "Curated decoration and professional installation services — the finishing touches that transform a house into a home." },
      { name: "Colour & Lighting Consultation", desc: "Expert guidance on colour palettes and lighting design to create the perfect atmosphere in every room." },
      { name: "Window Treatment Design & Installation", desc: "Custom window treatments designed and installed to complement your interior — from sheer linens to architectural shutters." },
      { name: "Furniture & Styling Package", desc: "For clients who have already finished construction. We handle furniture layout, sourcing, decor styling, and full installation — the complete finishing layer that brings a space to life." },
    ],
  },
  {
    id: "03",
    title: "Commercial & Hospitality",
    tagline: "Environments that perform.",
    services: [
      { name: "Commercial Design", desc: "Interior design for offices, co-working spaces, and professional environments that reflect brand identity and support productivity." },
      { name: "Retail Design", desc: "Intuitive retail environments that guide the customer journey, strengthen brand presence, and drive engagement." },
      { name: "Hospitality Design", desc: "Hotel, restaurant, and resort interiors that create memorable guest experiences — warm, refined, and architecturally considered." },
      { name: "Space Consultation", desc: "A focused consultation to assess your commercial space and provide clear, actionable design direction." },
    ],
  },
  {
    id: "04",
    title: "Technical & Project Management",
    tagline: "Precision at every stage.",
    services: [
      { name: "CAD Drafting & 3D Renderings", desc: "Professional technical drawings and photorealistic 3D renderings — so you can see your space before a single wall is touched." },
      { name: "Floor Plans, Elevations & Sectional Details", desc: "Comprehensive technical documentation for builders, contractors, and council submissions." },
      { name: "Lighting / RCP Plans & Electrical Plans", desc: "Detailed reflected ceiling plans, lighting layouts, and electrical plans coordinated with your design intent." },
      { name: "Project Implementation & Management", desc: "End-to-end project management — coordinating contractors, suppliers, and trades to deliver your project on time and on budget." },
      { name: "Schedule & Cost Management", desc: "Rigorous scheduling and cost oversight to keep your project on track and within budget at every stage." },
      { name: "FF&E Source & Selection", desc: "Furniture, fixtures, and equipment sourcing from our curated network of local and international suppliers." },
    ],
  },
];

export default function Services() {
  return (
    <div className="min-h-screen bg-[#f7f3ee]">
      <Navigation />

      {/* Page Header */}
      <div className="relative pt-40 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img src={SERVICES_BG} alt="Architectural material detail" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[rgba(26,22,18,0.80)]" />
        </div>
        <div className="relative container">
          <AnimateSection>
            <p className="label-text text-[#9a7c5f] mb-4">What We Offer</p>
            <h1 className="font-display text-[clamp(3rem,7vw,6rem)] leading-[1.0] text-[#f7f3ee] max-w-3xl">
              Full-Spectrum Design Services
            </h1>
            <div className="w-16 h-px bg-[#9a7c5f] mt-8 mb-8" />
            <p className="font-body font-light text-[1.05rem] text-[rgba(247,243,238,0.7)] max-w-xl leading-relaxed">
              From architectural new builds to intimate space consultations, Innerpiece offers a complete suite of interior design services — tailored to residential, commercial, and hospitality clients across Maui and beyond.
            </p>
          </AnimateSection>
        </div>
      </div>

      {/* Service Categories */}
      {serviceCategories.map((cat, catIdx) => (
        <section
          key={cat.id}
          className={`section-pad ${catIdx % 2 === 0 ? "bg-[#f7f3ee]" : "bg-[#faf8f5]"}`}
        >
          <div className="container">
            <AnimateSection className="grid grid-cols-1 lg:grid-cols-[1fr_2fr] gap-12 lg:gap-20">
              {/* Category Header */}
              <div className="lg:sticky lg:top-32 lg:self-start">
                <p className="font-display text-[4rem] text-[#d4c4b0] leading-none mb-4">{cat.id}</p>
                <h2 className="font-display text-[1.8rem] text-[#2c2420] mb-3">{cat.title}</h2>
                <p className="font-accent italic text-[1rem] text-[#9a7c5f]">{cat.tagline}</p>
                <div className="w-12 h-px bg-[#9a7c5f] mt-6" />
              </div>

              {/* Services List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {cat.services.map((service) => (
                  <div
                    key={service.name}
                    className="p-7 border border-[#d4c4b0] hover:border-[#9a7c5f] hover:bg-[rgba(154,124,95,0.04)] transition-all duration-300"
                  >
                    <h3 className="font-display text-[1.05rem] text-[#2c2420] mb-3">{service.name}</h3>
                    <p className="font-body font-light text-[0.875rem] text-[#5a4a3a] leading-relaxed">{service.desc}</p>
                  </div>
                ))}
              </div>
            </AnimateSection>
          </div>
        </section>
      ))}

      {/* Mid-page image break */}
      <div className="relative h-[50vh] overflow-hidden">
        <img src={KITCHEN_IMG} alt="Luxury Maui kitchen" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-[rgba(26,22,18,0.4)]" />
        <div className="absolute inset-0 flex items-center justify-center">
          <AnimateSection className="text-center px-6">
            <p className="font-accent italic text-[clamp(1.5rem,4vw,2.5rem)] text-[#f7f3ee] max-w-2xl leading-relaxed">
              "We love to work closely and efficiently with Architects, Building Developers, and General Contractors to handle any new-build, renovation, or refresh project."
            </p>
            <p className="label-text text-[#9a7c5f] mt-6">— Daruni Gotel, Founder</p>
          </AnimateSection>
        </div>
      </div>

      {/* Digital Products */}
      <section className="section-pad bg-[#2c2420]">
        <div className="container">
          <AnimateSection className="mb-14">
            <p className="label-text text-[#9a7c5f] mb-4">Digital Services</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#f7f3ee]">
              Start from anywhere.
            </h2>
          </AnimateSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Design & Space Consultation",
                price: "$175/hour · 60–90 min",
                desc: "A focused in-person or Zoom consultation where you receive actionable design direction tailored to your space. Great for homeowners not ready for full service.",
                deliverables: ["Layout advice", "Materials direction", "Furniture layout", "Lighting strategy", "Renovation planning"],
              },
              {
                title: "Floor Plan Review Audit & Proposed Revised Layout",
                price: "From $1,000",
                desc: "Many clients struggle with space planning. We provide a professional review of your floor plan and deliver a clear path forward.",
                deliverables: ["Improved furniture layout", "Circulation suggestions", "Spatial improvements"],
              },
              {
                title: "Mini Design & Spec Package",
                price: "From $2,500",
                desc: "A comprehensive room-by-room design and specification package to guide your renovation or decoration project.",
                deliverables: ["Colour palette", "Material selections", "Furniture recommendations", "Sourcing guide"],
              },
              {
                title: "Developer & Builder Design Consulting",
                price: "Billed hourly",
                desc: "A huge opportunity on Maui. We offer design consulting services for spec homes, condo remodels, boutique developments, and hospitality projects.",
                deliverables: ["Finish palettes", "Lighting direction", "Cabinetry design", "Interior specifications"],
              },
              {
                title: "Pre-Renovation Design Blueprint",
                price: "From $1,500",
                desc: "Homeowners often start renovations without a plan. We deliver a complete design blueprint before construction begins — preventing expensive mistakes.",
                deliverables: ["Layout plan", "Lighting concept", "Finish palette", "Cabinetry concepts"],
              },
              {
                title: "Digital Design Guides",
                price: "From $50–$500",
                desc: "Turn expertise into accessible products. Downloadable guides that empower homeowners to make confident design decisions on their own.",
                deliverables: ["Renovation planning guide", "Finish selection guide", "Kitchen planning kit", "Furniture layout guide", "Lighting design guide"],
              },
              {
                title: "Furniture & Styling Package",
                price: "From $2,500",
                desc: "For clients who have already finished construction. A great service for second-home owners who need the space furnished and styled without the full design process.",
                deliverables: ["Furniture layout", "Furniture sourcing", "Decor styling", "Installation"],
              },
            ].map((product) => (
              <div
                key={product.title}
                className="bg-[rgba(247,243,238,0.05)] border border-[rgba(247,243,238,0.1)] p-8 hover:bg-[rgba(154,124,95,0.1)] hover:border-[rgba(154,124,95,0.3)] transition-all duration-300"
              >
                <p className="font-display text-[1.1rem] text-[#f7f3ee] mb-3 leading-snug">{product.title}</p>
                <p className="font-display text-lg text-[#9a7c5f] mb-5">{product.price}</p>
                <p className="font-body font-light text-[0.875rem] text-[rgba(247,243,238,0.6)] leading-relaxed mb-6">{product.desc}</p>
                <ul className="flex flex-col gap-2">
                  {product.deliverables.map((d) => (
                    <li key={d} className="flex items-center gap-3">
                      <span className="w-1 h-1 rounded-full bg-[#9a7c5f] shrink-0" />
                      <span className="font-body text-[0.78rem] text-[rgba(247,243,238,0.5)] tracking-wide">{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <div className="relative h-[60vh] overflow-hidden">
        <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/IMG_9491_a06eacd7.jpeg" alt="Leather and wallcovering samples" className="w-full h-full object-cover object-center" />
        <div className="absolute inset-0 bg-[rgba(26,22,18,0.65)]" />
        <div className="absolute inset-0 flex items-center justify-center">
          <AnimateSection className="text-center px-6 max-w-2xl">
            <p className="label-text text-[#9a7c5f] mb-4">Begin Your Project</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#f7f3ee] mb-6">
              Not sure where to start?<br />
              <em>That's exactly what we're here for.</em>
            </h2>
            <p className="font-body font-light text-[1rem] text-[rgba(247,243,238,0.75)] leading-relaxed mb-10">
              Book a strategy session with Daruni at $175/hour (30-min minimum). We'll discuss your project, clarify your vision, and map out the right path forward.
            </p>
            <a href="https://calendly.com/daruniinnerpiece/30min" target="_blank" rel="noopener noreferrer" className="btn-primary">
              Book a Strategy Session
            </a>
          </AnimateSection>
        </div>
      </div>

      <Footer />
    </div>
  );
}
