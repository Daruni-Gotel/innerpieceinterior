/*
 * INNERPIECE — Contact / Strategy Session Page
 * Design: Pacific Modernism — warm, personal, architectural
 * Includes: contact form, strategy session info, contact details
 */

import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const BEDROOM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/daruni-tradeshow2_65180801.jpg";
const CONTACT_BEFORE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/contact-before_06e598f6.jpg";
const CONTACT_AFTER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/contact-after_e6699708.jpg";

function BeforeAfterSlider({ before, after }: { before: string; after: string }) {
  const [sliderPos, setSliderPos] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isActive = useRef(false);

  const updatePos = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pct = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pct);
  };

  const onPointerDown = (e: React.PointerEvent) => {
    isActive.current = true;
    (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
    updatePos(e.clientX);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!isActive.current) return;
    updatePos(e.clientX);
  };
  const onPointerUp = () => { isActive.current = false; };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[320px] overflow-hidden cursor-col-resize select-none touch-none"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
    >
      <img src={after} alt="After" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
        <img src={before} alt="Before" className="absolute inset-0 h-full object-cover" style={{ width: containerRef.current ? containerRef.current.offsetWidth + 'px' : '100%' }} />
      </div>
      <div className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg" style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white shadow-lg flex items-center justify-center pointer-events-none">
          <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
            <path d="M5 8H1M1 8L3 6M1 8L3 10M11 8H15M15 8L13 6M15 8L13 10" stroke="#9a7c5f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>
      <div className="absolute bottom-3 left-3 bg-black/50 text-white text-xs px-2 py-1 font-body pointer-events-none">BEFORE</div>
      <div className="absolute bottom-3 right-3 bg-black/50 text-white text-xs px-2 py-1 font-body pointer-events-none">AFTER</div>
    </div>
  );
}

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function AnimateSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, inView } = useInView();
  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${
        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
    >
      {children}
    </div>
  );
}

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    projectType: "",
    location: "",
    timeline: "",
    budget: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success("Your enquiry has been sent. Daruni will be in touch within 48 hours.");
  };

  return (
    <div className="min-h-screen bg-[#f7f3ee]">
      <Navigation />

      {/* Page Header */}
      <div className="relative pt-40 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img src={BEDROOM_IMG} alt="Maui luxury bedroom" className="w-full h-full object-cover" style={{ objectPosition: 'center 22%' }} />
          <div className="absolute inset-0 bg-gradient-to-r from-[rgba(26,22,18,0.88)] via-[rgba(26,22,18,0.65)] to-[rgba(26,22,18,0.3)]" />
        </div>
        <div className="relative container">
          <AnimateSection>
            <p className="label-text text-[#9a7c5f] mb-4">Let's Connect</p>
            <h1 className="font-display text-[clamp(3rem,7vw,6rem)] leading-[1.0] text-[#f7f3ee] max-w-2xl">
              Book a Strategy Session
            </h1>
            <div className="w-16 h-px bg-[#9a7c5f] mt-8 mb-8" />
            <p className="font-body font-light text-[1.05rem] text-[rgba(247,243,238,0.7)] max-w-lg leading-relaxed">
              Every great space begins with a great conversation. Tell us about your project and we'll be in touch within 48 hours.
            </p>
          </AnimateSection>
        </div>
      </div>

      {/* Main Content */}
      <section className="section-pad">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.6fr] gap-16 lg:gap-24">

            {/* Left: Info */}
            <AnimateSection className="flex flex-col gap-12">
              {/* What to expect */}
              <div>
                <p className="label-text mb-5">What to Expect</p>
                <h2 className="font-display text-2xl text-[#2c2420] mb-3">
                  Design & Space Consultation
                </h2>
                <p className="font-body text-[0.75rem] tracking-[0.15em] uppercase text-[#9a7c5f] mb-4">60–90 minutes · In-person or Zoom · $175/hour</p>
                <p className="font-body font-light text-[0.9rem] text-[#5a4a3a] leading-relaxed mb-6">
                  A focused consultation where you receive actionable design direction tailored to your space and goals.
                </p>
                <div className="mb-6">
                  <p className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f] mb-3">What I Cover</p>
                  <div className="flex flex-col gap-2">
                    {["Layout advice", "Materials direction", "Furniture layout", "Lighting strategy", "Renovation planning"].map((item) => (
                      <div key={item} className="flex items-center gap-3">
                        <span className="w-4 h-px bg-[#9a7c5f] shrink-0" />
                        <p className="font-body text-[0.875rem] text-[#5a4a3a]">{item}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <p className="font-body font-light text-[0.85rem] text-[#9a7c5f] italic">Great for homeowners not ready for full service.</p>
              </div>

              {/* Contact details */}
              <div>
                <p className="label-text mb-5">Direct Contact</p>
                <div className="flex flex-col gap-4">
                  <a href="mailto:innerpieceinterior@gmail.com" className="flex items-center gap-3 group">
                    <span className="w-8 h-px bg-[#9a7c5f] shrink-0" />
                    <span className="font-body text-[0.875rem] text-[#5a4a3a] group-hover:text-[#9a7c5f] transition-colors">innerpieceinterior@gmail.com</span>
                  </a>
                  <a href="tel:+18082142058" className="flex items-center gap-3 group">
                    <span className="w-8 h-px bg-[#9a7c5f] shrink-0" />
                    <span className="font-body text-[0.875rem] text-[#5a4a3a] group-hover:text-[#9a7c5f] transition-colors">808 · 214 · 2058</span>
                  </a>
                  <div className="flex items-start gap-3">
                    <span className="w-8 h-px bg-[#9a7c5f] shrink-0 mt-2" />
                    <span className="font-body text-[0.875rem] text-[#5a4a3a] leading-relaxed">Haiku, North Shore<br />Maui, Hawai'i</span>
                  </div>
                </div>
              </div>
            </AnimateSection>

            {/* Right: Form */}
            <AnimateSection>
              {submitted ? (
                <div className="flex flex-col items-center justify-center h-full py-20 text-center">
                  <div className="w-px h-16 bg-[#9a7c5f] mx-auto mb-8" />
                  <h2 className="font-display text-3xl text-[#2c2420] mb-4">
                    Thank you, <em>with aloha.</em>
                  </h2>
                  <p className="font-body font-light text-[1rem] text-[#5a4a3a] max-w-sm leading-relaxed mb-8">
                    Your enquiry has been received. Daruni will be in touch within 48 hours to schedule your strategy session.
                  </p>
                  <Link href="/" className="btn-outline">Return Home</Link>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-6">
                  <p className="label-text mb-2">Your Project Details</p>

                  {/* Name + Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div className="flex flex-col gap-2">
                      <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Full Name *</label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={form.name}
                        onChange={handleChange}
                        className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] placeholder:text-[#c4b5a0] transition-colors"
                        placeholder="Your name"
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Email Address *</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={form.email}
                        onChange={handleChange}
                        className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] placeholder:text-[#c4b5a0] transition-colors"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex flex-col gap-2">
                    <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] placeholder:text-[#c4b5a0] transition-colors"
                      placeholder="Your phone number"
                    />
                  </div>

                  {/* Project Type */}
                  <div className="flex flex-col gap-2">
                    <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Project Type *</label>
                    <select
                      name="projectType"
                      required
                      value={form.projectType}
                      onChange={handleChange}
                      className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] transition-colors appearance-none"
                    >
                      <option value="" disabled>Select project type</option>
                      <option>New Build</option>
                      <option>Full Renovation / Remodel</option>
                      <option>Partial Renovation</option>
                      <option>Residential Interior Design</option>
                      <option>Commercial Design</option>
                      <option>Retail Design</option>
                      <option>Hospitality Design</option>
                      <option>Space Consultation</option>
                      <option>Digital Service</option>
                      <option>Other</option>
                    </select>
                  </div>

                  {/* Location + Timeline */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div className="flex flex-col gap-2">
                      <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Project Location</label>
                      <input
                        type="text"
                        name="location"
                        value={form.location}
                        onChange={handleChange}
                        className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] placeholder:text-[#c4b5a0] transition-colors"
                        placeholder="Maui, Hawai'i"
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Desired Timeline</label>
                      <select
                        name="timeline"
                        value={form.timeline}
                        onChange={handleChange}
                        className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] transition-colors appearance-none"
                      >
                        <option value="">Select timeline</option>
                        <option>As soon as possible</option>
                        <option>Within 3 months</option>
                        <option>3–6 months</option>
                        <option>6–12 months</option>
                        <option>Planning stage</option>
                      </select>
                    </div>
                  </div>

                  {/* Budget */}
                  <div className="flex flex-col gap-2">
                    <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Approximate Budget</label>
                    <select
                      name="budget"
                      value={form.budget}
                      onChange={handleChange}
                      className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] transition-colors appearance-none"
                    >
                      <option value="">Select budget range</option>
                      <option>Under $25,000</option>
                      <option>$25,000 – $75,000</option>
                      <option>$75,000 – $150,000</option>
                      <option>$150,000 – $500,000</option>
                      <option>$500,000+</option>
                      <option>To be determined</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div className="flex flex-col gap-2">
                    <label className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">Tell Us About Your Vision *</label>
                    <textarea
                      name="message"
                      required
                      rows={5}
                      value={form.message}
                      onChange={handleChange}
                      className="bg-transparent border-b border-[#d4c4b0] focus:border-[#9a7c5f] outline-none py-3 font-body text-[0.9rem] text-[#2c2420] placeholder:text-[#c4b5a0] transition-colors resize-none"
                      placeholder="Share your vision, inspiration, and any details about your project..."
                    />
                  </div>

                  <button type="submit" className="btn-primary self-start mt-2">
                    Send Enquiry
                  </button>

                  <p className="font-body text-[0.75rem] text-[#c4b5a0] leading-relaxed">
                    We respond to all enquiries within 48 hours. Your information is kept strictly confidential.
                  </p>
                </form>
              )}
            </AnimateSection>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
