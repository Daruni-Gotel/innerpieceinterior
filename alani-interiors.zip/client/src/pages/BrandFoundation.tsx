/*
 * INNERPIECE — Brand Foundation / Our Story Page
 * Design: Pacific Modernism — editorial, warm, architectural
 * Content: Brand story, philosophy, credentials, values, design process
 */

import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const PORTRAIT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/daruni-portrait_afb81ae3.png";
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hero-real_e8aec7f9.png";
const KITCHEN_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/portfolio-kitchen-4HzJRMyxE7Xb2Ncwo4EHY6.webp";
const SERVICES_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/services-bg-kq74p5LXTqFwyK3AJm7sAV.webp";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function AnimateSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, inView } = useInView();
  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${
        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
    >
      {children}
    </div>
  );
}

export default function BrandFoundation() {
  return (
    <div className="min-h-screen bg-[#f7f3ee]">
      <Navigation />

      {/* Page Header */}
      <div className="relative pt-40 pb-24 overflow-hidden bg-[#1a1612]">
        <div className="absolute inset-0 opacity-25">
          <img src={HERO_IMG} alt="Maui interior" className="w-full h-full object-cover" />
        </div>
        <div className="relative container">
          <AnimateSection>
            <p className="label-text text-[#9a7c5f] mb-4">Our Story</p>
            <h1 className="font-display text-[clamp(3rem,7vw,6rem)] leading-[1.0] text-[#f7f3ee] max-w-3xl">
              Brand Foundation
            </h1>
            <div className="w-16 h-px bg-[#9a7c5f] mt-8 mb-8" />
            <p className="font-body font-light text-[1.05rem] text-[rgba(247,243,238,0.7)] max-w-xl leading-relaxed">
              The story, philosophy, and values behind Innerpiece Interior Design and Architecture.
            </p>
          </AnimateSection>
        </div>
      </div>

      {/* Brand Story */}
      <section className="section-pad bg-[#f7f3ee]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <AnimateSection className="img-zoom">
              <img src={PORTRAIT_IMG} alt="Daruni Gotel" className="w-full h-[580px] object-cover object-top" />
            </AnimateSection>
            <AnimateSection>
              <p className="label-text mb-6">The Designer</p>
              <h2 className="font-display text-[clamp(2rem,4vw,3rem)] leading-[1.15] text-[#2c2420] mb-8">
                Daruni Gotel<br />
                <em>ASID · Founder</em>
              </h2>
              <div className="w-16 h-px bg-[#9a7c5f] mb-8" />
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-5">
                With an early childhood passion for design that has only deepened over 25+ years of professional practice, Daruni Gotel is one of Maui's most respected interior designers and architects. Her career began in London — one of the world's most demanding design markets — where she honed her craft across residential, commercial, and retail projects of the highest calibre.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-5">
                Today, permanently based in Haiku on Maui's North Shore, Daruni brings that international expertise to the island she loves — infusing every project with a deep reverence for the 'āina, the natural beauty of Hawai'i, and the unique way of life that Maui offers.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-10">
                Her love and interest for design continues through international travel, attending the latest trade shows, and visiting showrooms around the world — ensuring that every Innerpiece project benefits from the very best of global design thinking, filtered through a distinctly island lens.
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="border border-[#d4c4b0] px-5 py-3">
                  <p className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">ASID Member</p>
                </div>
                <div className="border border-[#d4c4b0] px-5 py-3">
                  <p className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">BA Honours — 3D Design & Interior Design</p>
                </div>
                <div className="border border-[#d4c4b0] px-5 py-3">
                  <p className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">BTEC National Diploma — Interior Design</p>
                </div>
                <div className="border border-[#d4c4b0] px-5 py-3">
                  <p className="font-body text-[0.7rem] tracking-[0.15em] uppercase text-[#9a7c5f]">25+ Years Experience</p>
                </div>
              </div>
            </AnimateSection>
          </div>
        </div>
      </section>

      {/* Brand Name & Meaning */}
      <section className="section-pad bg-[#2c2420]">
        <div className="container max-w-4xl mx-auto text-center">
          <AnimateSection>
            <p className="label-text text-[#9a7c5f] mb-8">The Name</p>
            <h2 className="font-display text-[clamp(2.5rem,5vw,4.5rem)] text-[#f7f3ee] leading-[1.1] mb-8">
              inner|piece
            </h2>
            <div className="w-16 h-px bg-[#9a7c5f] mx-auto mb-10" />
            <p className="font-body font-light text-[1.1rem] text-[rgba(247,243,238,0.75)] leading-relaxed mb-6">
              The name holds a deliberate duality. <em className="font-accent italic text-[#f7f3ee]">Inner peace</em> — the tranquility that a beautifully designed space creates within you. And <em className="font-accent italic text-[#f7f3ee]">a piece of the interior</em> — the tangible, crafted elements that make a space uniquely yours.
            </p>
            <p className="font-body font-light text-[1.1rem] text-[rgba(247,243,238,0.75)] leading-relaxed">
              Together, they capture the essence of what Innerpiece does: design spaces that are not just beautiful to look at, but deeply felt — spaces that bring you home to yourself.
            </p>
          </AnimateSection>
        </div>
      </section>

      {/* Core Values */}
      <section className="section-pad bg-[#faf8f5]">
        <div className="container">
          <AnimateSection className="text-center mb-16">
            <p className="label-text mb-4">What We Stand For</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#2c2420]">
              Our core values.
            </h2>
          </AnimateSection>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-[#d4c4b0]">
            {[
              {
                num: "I",
                title: "Listen First",
                body: "Every project begins with deep listening. We take the time to truly understand you — your lifestyle, your tastes, your needs — before a single design decision is made.",
              },
              {
                num: "II",
                title: "Honour the 'Āina",
                body: "We hold a sympathetic awareness for Maui's land, light, and natural resources. Every design decision is made with respect for the island we call home.",
              },
              {
                num: "III",
                title: "Commit to Completion",
                body: "We are with you every step of the way — from the first conversation to the final installation. Our commitment to full project completion is unwavering.",
              },
              {
                num: "IV",
                title: "Design With Integrity",
                body: "We believe in honest, thoughtful design — spaces that are beautiful because they are true to you, not because they follow a trend.",
              },
            ].map((value) => (
              <AnimateSection key={value.num} className="bg-[#faf8f5] p-10">
                <p className="font-accent italic text-[2.5rem] text-[#d4c4b0] leading-none mb-6">{value.num}</p>
                <h3 className="font-display text-xl text-[#2c2420] mb-4">{value.title}</h3>
                <p className="font-body font-light text-[0.875rem] text-[#5a4a3a] leading-relaxed">{value.body}</p>
              </AnimateSection>
            ))}
          </div>
        </div>
      </section>

      {/* Design Philosophy */}
      <section className="section-pad bg-[#f7f3ee]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-start">
            <AnimateSection>
              <p className="label-text mb-6">Design Philosophy</p>
              <h2 className="font-display text-[clamp(2rem,4vw,3rem)] leading-[1.15] text-[#2c2420] mb-8">
                Elevated Island Contemporary.
              </h2>
              <div className="w-16 h-px bg-[#9a7c5f] mb-8" />
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-5">
                Innerpiece's design language is rooted in what we call <em className="font-accent italic">Elevated Island Contemporary</em> — a philosophy that honours the natural beauty and spirit of Maui while embracing architectural precision and international design standards.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-5">
                It is quietly powerful. Warm and refined. Architectural in its bones, but deeply human in its soul. It is design that does not shout, but commands attention. Design that does not follow trends, but sets them.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-10">
                Every Innerpiece project is a bespoke expression of this philosophy — shaped by the unique character of the site, the client, and the island itself.
              </p>
              <blockquote className="border-l-2 border-[#9a7c5f] pl-6">
                <p className="font-accent italic text-[1.15rem] text-[#2c2420] leading-relaxed">
                  "Design is not just what it looks and feels like. Design is how it works."
                </p>
                <cite className="font-body text-[0.75rem] tracking-widest uppercase text-[#9a7c5f] mt-3 block not-italic">
                  — Steve Jobs
                </cite>
              </blockquote>
              <div className="img-zoom mt-8">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/staircase-architectural_3578725c.jpeg"
                  alt="Architectural staircase detail"
                  className="w-full object-cover"
                />
              </div>
            </AnimateSection>


          </div>
        </div>
      </section>

      {/* Website Structure Section */}
      <section className="section-pad bg-[#2c2420]">
        <div className="container">
          <AnimateSection className="mb-14">
            <p className="label-text text-[#9a7c5f] mb-4">Website Structure</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#f7f3ee]">
              How to navigate <em>Innerpiece.</em>
            </h2>
          </AnimateSection>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { page: "Home", path: "/", desc: "Our brand story, process, services overview, and the invitation to begin." },
              { page: "Work", path: "/work", desc: "A curated portfolio of residential, commercial, and hospitality projects." },
              { page: "Services", path: "/services", desc: "The full spectrum of design services, from new builds to digital consultations." },
              { page: "Contact", path: "/contact", desc: "Book your complimentary strategy session and begin your project." },
            ].map((item) => (
              <Link key={item.page} href={item.path}>
                <div className="border border-[rgba(247,243,238,0.1)] p-7 hover:border-[#9a7c5f] hover:bg-[rgba(154,124,95,0.08)] transition-all duration-300 cursor-pointer h-full">
                  <p className="label-text text-[#9a7c5f] mb-3">{item.page}</p>
                  <p className="font-body text-[0.875rem] text-[rgba(247,243,238,0.6)] leading-relaxed">{item.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-pad bg-[#faf8f5]">
        <div className="container text-center">
          <AnimateSection>
            <div className="w-px h-16 bg-[#d4c4b0] mx-auto mb-10" />
            <p className="label-text mb-4">With Aloha</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#2c2420] mb-6">
              Ready to design <em>your innerpiece?</em>
            </h2>
            <p className="font-body font-light text-[1rem] text-[#5a4a3a] max-w-xl mx-auto mb-10 leading-relaxed">
              Whether you have a clear vision or are just beginning to explore, we'd love to hear from you. Let's create something extraordinary together.
            </p>
            <a href="https://calendly.com/daruniinnerpiece/30min" target="_blank" rel="noopener noreferrer" className="btn-primary">
              Book a Strategy Session
            </a>
          </AnimateSection>
        </div>
      </section>

      <Footer />
    </div>
  );
}
