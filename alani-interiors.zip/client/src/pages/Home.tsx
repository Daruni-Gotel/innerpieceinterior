/*
 * INNERPIECE — Homepage
 * Design: Pacific Modernism
 * Framework: StoryBrand — Hero → Problem → Hero Journey → Guide → Process → Services → Digital Products → CTA
 * Typography: Playfair Display (display) + Jost (body) + Cormorant Garamond (accent)
 * Palette: Parchment bg, Charcoal text, Sand surface, Bronze accent
 */

import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

// Image CDN URLs
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/hero-real_e8aec7f9.png";
const PORTRAIT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/daruni-portrait_afb81ae3.png";
const KITCHEN_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/IMG_9958_2e27ff42.jpeg";
const BEDROOM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/portfolio-bedroom-4B2WQC3uf6QihbcJPepwtr.webp";
const SERVICES_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663423570573/KREV6AGEGjxgfKcEFFoHb8/services-bg-kq74p5LXTqFwyK3AJm7sAV.webp";

// Intersection observer hook for scroll animations
function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function AnimateSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, inView } = useInView();
  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${
        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
    >
      {children}
    </div>
  );
}

export default function Home() {
  const [heroLoaded, setHeroLoaded] = useState(false);

  return (
    <div className="min-h-screen bg-[#f7f3ee]">
      <Navigation />

      {/* ─── HERO SECTION ─────────────────────────────────────────────── */}
      <section className="relative h-screen min-h-[640px] overflow-hidden">
        {/* Background image */}
        <img
          src={HERO_IMG}
          alt="Maui luxury interior living room"
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${heroLoaded ? "opacity-100" : "opacity-0"}`}
          onLoad={() => setHeroLoaded(true)}
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[rgba(26,22,18,0.72)] via-[rgba(26,22,18,0.35)] to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[rgba(26,22,18,0.4)] via-transparent to-transparent" />

        {/* Hero content */}
        <div className="relative h-full container flex flex-col justify-end pb-24 md:pb-32">
          <div className="max-w-2xl">
            <p className="label-text text-[#9a7c5f] mb-5 animate-fade-up">
              Maui, Hawai'i · Est. 2018
            </p>
            <h1 className="font-display text-[clamp(2.8rem,6vw,5.5rem)] leading-[1.05] text-[#faf8f5] mb-6 animate-fade-up delay-100">
              Elevated Island Living,<br />
              <em>Designed From Within.</em>
            </h1>
            <p className="font-body font-light text-[1.05rem] text-[rgba(250,248,245,0.8)] leading-relaxed mb-10 max-w-lg animate-fade-up delay-200">
              Innerpiece Interior Design &amp; Architecture creates quietly powerful, warm, and refined spaces for discerning clients across Maui and beyond.
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-up delay-300">
              <a href="https://calendly.com/daruniinnerpiece/30min" target="_blank" rel="noopener noreferrer" className="btn-primary">
                Book a Strategy Session
              </a>
              <Link href="/work" className="btn-outline-light">
                View Our Work
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-8 md:right-16 flex flex-col items-center gap-3 animate-fade-up delay-500">
          <div className="w-px h-14 bg-[rgba(250,248,245,0.3)]" style={{animation: 'scrollPulse 2s ease-in-out infinite'}} />
        </div>
        <style>{`
          @keyframes scrollPulse {
            0%, 100% { opacity: 0.3; transform: scaleY(1); }
            50% { opacity: 0.7; transform: scaleY(1.15); }
          }
        `}</style>
      </section>

      {/* ─── MARQUEE / TAGLINE STRIP ──────────────────────────────────── */}
      <div className="bg-[#2c2420] py-4 overflow-hidden">
        <div className="flex gap-0 whitespace-nowrap" style={{animation: 'marquee 40s linear infinite'}}>
          {Array(4).fill(null).map((_, i) => (
            <span key={i} className="font-accent italic text-[1rem] text-[rgba(247,243,238,0.45)] shrink-0 pr-0">
              &nbsp;&nbsp;&nbsp;Elevated Island Living&nbsp;&nbsp;&nbsp;·&nbsp;&nbsp;&nbsp;Designed From Within&nbsp;&nbsp;&nbsp;·&nbsp;&nbsp;&nbsp;Residential · Commercial · Hospitality&nbsp;&nbsp;&nbsp;·&nbsp;&nbsp;&nbsp;Maui, Hawai'i&nbsp;&nbsp;&nbsp;·&nbsp;&nbsp;&nbsp;With Aloha&nbsp;&nbsp;&nbsp;·
            </span>
          ))}
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
      `}</style>

      {/* ─── THE PROBLEM ──────────────────────────────────────────────── */}
      <section className="section-pad bg-[#f7f3ee]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <AnimateSection>
              <p className="label-text mb-6">The Challenge</p>
              <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] leading-[1.15] text-[#2c2420] mb-8">
                A beautiful home doesn't happen by accident — and the wrong choices are costly.
              </h2>
              <div className="w-16 h-px bg-[#9a7c5f] mb-8" />
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-6">
                You have a vision for your space — a sense of how it should feel, how it should live. But translating that vision into reality is overwhelming. The options are endless, the decisions are permanent, and one wrong move can cost thousands.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed">
                Without the right guide, you risk a home that looks assembled rather than designed — a space that doesn't reflect the life you've worked hard to build.
              </p>
            </AnimateSection>

            <AnimateSection className="grid grid-cols-2 gap-4">
              {[
                { num: "25+", label: "Years of Experience" },
                { num: "3", label: "Sectors: Residential, Commercial, Hospitality" },
                { num: "100%", label: "Project Completion Rate" },
                { num: "ASID", label: "Certified Member" },
              ].map((stat) => (
                <div
                  key={stat.num}
                  className="bg-[#faf8f5] border border-[#d4c4b0] p-8 flex flex-col justify-between"
                >
                  <p className="font-display text-[2.5rem] text-[#9a7c5f] leading-none mb-3">{stat.num}</p>
                  <p className="font-body text-[0.75rem] text-[#5a4a3a] leading-snug tracking-wide">{stat.label}</p>
                </div>
              ))}
            </AnimateSection>
          </div>
        </div>
      </section>

      {/* ─── YOU ARE THE HERO ─────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-[#2c2420]">
        <div className="absolute inset-0">
          <img src={KITCHEN_IMG} alt="Maui luxury kitchen" className="w-full h-full object-cover opacity-20" />
        </div>
        <div className="relative container section-pad">
          <AnimateSection className="max-w-3xl mx-auto text-center">
            <p className="label-text text-[#9a7c5f] mb-6">Your Vision Matters</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3.5rem)] leading-[1.15] text-[#f7f3ee] mb-8">
              You are the visionary.<br />
              <em>Your home is your story.</em>
            </h2>
            <div className="w-16 h-px bg-[#9a7c5f] mx-auto mb-8" />
            <p className="font-body font-light text-[1.05rem] text-[rgba(247,243,238,0.75)] leading-relaxed mb-6">
              You've built a life of intention. Your home should be a testament to that — a deeply personal sanctuary that reflects your journey, your values, and the way you want to live. Not a showroom. Not a trend. <em className="font-accent italic">Yours.</em>
            </p>
            <p className="font-body font-light text-[1.05rem] text-[rgba(247,243,238,0.75)] leading-relaxed">
              You are the hero of this story. We are simply the guide who helps you bring it to life — with expertise, care, and a deep reverence for the land and light of Maui.
            </p>
          </AnimateSection>
        </div>
      </section>

      {/* ─── THE GUIDE — DARUNI ───────────────────────────────────────── */}
      <section className="section-pad bg-[#faf8f5]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            {/* Portrait */}
            <AnimateSection className="relative img-zoom order-2 lg:order-1">
              <img
                src={PORTRAIT_IMG}
                alt="Daruni Gotel, Interior Designer"
                className="w-full h-[600px] object-cover object-center"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(26,22,18,0.6)] to-transparent p-8">
                <p className="font-display text-xl text-[#f7f3ee]">Daruni Gotel</p>
                <p className="label-text text-[#9a7c5f] mt-1">ASID · Founder, Innerpiece</p>
              </div>
            </AnimateSection>

            {/* Text */}
            <AnimateSection className="order-1 lg:order-2">
              <p className="label-text mb-6">Your Guide</p>
              <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] leading-[1.15] text-[#2c2420] mb-8">
                Design rooted in listening, <em>built on trust.</em>
              </h2>
              <div className="w-16 h-px bg-[#9a7c5f] mb-8" />
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-5">
                With over 25 years of international design experience — from London's most demanding residential projects to Maui's most celebrated hospitality spaces — Daruni Gotel brings a rare combination of architectural precision and island warmth to every project.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-5">
                As an ASID-certified designer, Daruni's process begins with listening. Deeply. She takes the time to understand not just what you want, but how you live — your rhythms, your rituals, your aspirations. That understanding becomes the foundation of every design decision.
              </p>
              <p className="font-body font-light text-[1rem] text-[#5a4a3a] leading-relaxed mb-10">
                Nestled in Haiku on Maui's North Shore, Innerpiece holds a sympathetic awareness for the island's 'āina — its land, its light, its spirit — and brings that reverence to every project.
              </p>
              <blockquote className="border-l-2 border-[#9a7c5f] pl-6 mb-10">
                <p className="font-accent italic text-[1.15rem] text-[#2c2420] leading-relaxed">
                  "The single most important key to success is to be a good listener."
                </p>
                <cite className="font-body text-[0.75rem] tracking-widest uppercase text-[#9a7c5f] mt-3 block not-italic">
                  — Kelly Wearstler
                </cite>
              </blockquote>
              <Link href="/brand-foundation" className="btn-outline">
                Our Story &amp; Philosophy
              </Link>
            </AnimateSection>
          </div>
        </div>
      </section>

      {/* ─── 3-STEP PROCESS ───────────────────────────────────────────── */}
      <section className="section-pad bg-[#f7f3ee]">
        <div className="container">
          <AnimateSection className="text-center mb-16">
            <p className="label-text mb-4">How We Work</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#2c2420]">
              A simple, <em>seamless process.</em>
            </h2>
          </AnimateSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-0 relative">
            {/* Connecting line */}
            <div className="hidden md:block absolute top-12 left-[16.66%] right-[16.66%] h-px bg-[#d4c4b0]" />

            {[
              {
                num: "01",
                title: "Consultation",
                body: "We begin with a deep, unhurried conversation about your vision, lifestyle, and aspirations. This is where we listen — and where your project truly begins.",
              },
              {
                num: "02",
                title: "Design",
                body: "We develop a comprehensive design plan — from space planning and concept boards to material selections, technical drawings, and 3D renderings.",
              },
              {
                num: "03",
                title: "Creation",
                body: "We manage every detail of the implementation — coordinating contractors, sourcing FF&E, and ensuring a seamless, stress-free transformation of your space.",
              },
            ].map((step, i) => (
              <AnimateSection
                key={step.num}
                className={`relative p-10 ${i < 2 ? "md:border-r border-[#d4c4b0]" : ""}`}
              >
                <p className="font-display text-[4rem] text-[#d4c4b0] leading-none mb-6">{step.num}</p>
                <h3 className="font-display text-xl text-[#2c2420] mb-4">{step.title}</h3>
                <p className="font-body font-light text-[0.9rem] text-[#5a4a3a] leading-relaxed">{step.body}</p>
              </AnimateSection>
            ))}
          </div>

          <AnimateSection className="text-center mt-14">
            <a href="https://calendly.com/daruniinnerpiece/30min" target="_blank" rel="noopener noreferrer" className="btn-primary">
              Begin Your Project
            </a>
          </AnimateSection>
        </div>
      </section>

      {/* ─── SERVICES OVERVIEW ────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={SERVICES_BG} alt="Architectural material detail" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[rgba(26,22,18,0.82)]" />
        </div>
        <div className="relative container section-pad">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <AnimateSection>
              <p className="label-text text-[#9a7c5f] mb-6">What We Offer</p>
              <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] leading-[1.15] text-[#f7f3ee] mb-8">
                Full-spectrum design,<br />
                <em>from concept to completion.</em>
              </h2>
              <p className="font-body font-light text-[1rem] text-[rgba(247,243,238,0.7)] leading-relaxed mb-10">
                From new builds and full renovations to concept design and FF&E sourcing, Innerpiece offers a complete suite of interior design and architecture services — tailored to residential, commercial, and hospitality clients.
              </p>
              <Link href="/services" className="btn-outline-light">
                Explore All Services
              </Link>
            </AnimateSection>

            <AnimateSection>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-[rgba(247,243,238,0.1)]">
                {[
                  "New Build & Architecture",
                  "Full Renovation & Remodel",
                  "Residential Design",
                  "Commercial & Retail Design",
                  "Hospitality Design",
                  "Concept & Mood Boards",
                  "CAD & 3D Renderings",
                  "FF&E Source & Selection",
                  "Project Management",
                  "Colour & Lighting Consultation",
                  "Window Treatment Design",
                  "Spatial Planning",
                ].map((service) => (
                  <div
                    key={service}
                    className="bg-[rgba(26,22,18,0.6)] p-5 border border-[rgba(247,243,238,0.07)] hover:bg-[rgba(154,124,95,0.15)] transition-colors duration-300"
                  >
                    <p className="font-body text-[0.8rem] text-[rgba(247,243,238,0.75)] tracking-wide leading-snug">{service}</p>
                  </div>
                ))}
              </div>
            </AnimateSection>
          </div>
        </div>
      </section>

      {/* ─── PORTFOLIO PREVIEW ────────────────────────────────────────── */}
      <section className="section-pad bg-[#f7f3ee]">
        <div className="container">
          <AnimateSection className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <p className="label-text mb-4">Selected Work</p>
              <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#2c2420]">
                Projects that speak<br /><em>for themselves.</em>
              </h2>
            </div>
            <Link href="/work" className="btn-outline shrink-0">
              View All Projects
            </Link>
          </AnimateSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                img: HERO_IMG,
                title: "Upcountry Residence",
                type: "Residential Design",
                location: "Maui, Hawai'i",
              },
              {
                img: KITCHEN_IMG,
                title: "Coastal Retreat",
                type: "New Build Interior",
                location: "Maui, Hawai'i",
              },
              {
                img: BEDROOM_IMG,
                title: "North Shore Sanctuary",
                type: "Full Renovation",
                location: "Haiku, Maui",
              },
              {
                img: SERVICES_BG,
                title: "Maui Thai Bistro",
                type: "Commercial Design",
                location: "Maui, Hawai'i",
              },
            ].map((project, i) => (
              <AnimateSection key={i} className="img-zoom group cursor-pointer">
                <Link href="/work">
                  <div className="relative overflow-hidden">
                    <img
                      src={project.img}
                      alt={project.title}
                      className="w-full h-[340px] md:h-[420px] object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[rgba(26,22,18,0.65)] via-transparent to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-7">
                      <p className="label-text text-[#9a7c5f] mb-2">{project.type} · {project.location}</p>
                      <p className="font-display text-xl text-[#f7f3ee]">{project.title}</p>
                    </div>
                  </div>
                </Link>
              </AnimateSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── DIGITAL PRODUCTS ─────────────────────────────────────────── */}
      <section className="section-pad bg-[#2c2420]">
        <div className="container">
          <AnimateSection className="text-center mb-14">
            <p className="label-text text-[#9a7c5f] mb-4">Digital Resources</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-[#f7f3ee]">
              Start designing <em>your innerpiece</em><br />from anywhere.
            </h2>
          </AnimateSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Floor Plan Review & Revised Layout",
                price: "From $350",
                desc: "Submit your existing floor plan and receive a professional audit with revised layout recommendations — optimised for flow, function, and beauty.",
                tag: "Digital Service",
              },
              {
                title: "Mini Design & Spec Package",
                price: "From $500 / room",
                desc: "A room-by-room design and specification package including colour palette, material selections, furniture recommendations, and sourcing guide.",
                tag: "Digital Product",
              },
              {
                title: "Space Consultation",
                price: "From $200",
                desc: "A focused one-hour virtual or in-person consultation to address your most pressing design questions and set a clear direction for your space.",
                tag: "Consultation",
              },
            ].map((product) => (
              <AnimateSection
                key={product.title}
                className="bg-[rgba(247,243,238,0.05)] border border-[rgba(247,243,238,0.1)] p-8 hover:bg-[rgba(154,124,95,0.1)] hover:border-[rgba(154,124,95,0.3)] transition-all duration-300"
              >
                <p className="label-text text-[#9a7c5f] mb-5">{product.tag}</p>
                <h3 className="font-display text-xl text-[#f7f3ee] mb-4 leading-snug">{product.title}</h3>
                <p className="font-body font-light text-[0.875rem] text-[rgba(247,243,238,0.6)] leading-relaxed mb-6">{product.desc}</p>
                <p className="font-display text-lg text-[#9a7c5f]">{product.price}</p>
              </AnimateSection>
            ))}
          </div>

          <AnimateSection className="text-center mt-12">
            <Link href="/contact" className="btn-outline-light">
              Enquire About Digital Services
            </Link>
          </AnimateSection>
        </div>
      </section>

      {/* ─── TESTIMONIAL / QUOTE ──────────────────────────────────────── */}
      <section className="section-pad bg-[#faf8f5]">
        <div className="container max-w-4xl mx-auto text-center">
          <AnimateSection>
            <div className="w-px h-16 bg-[#d4c4b0] mx-auto mb-10" />
            <blockquote>
              <p className="font-accent italic text-[clamp(1.4rem,3vw,2.2rem)] text-[#2c2420] leading-relaxed mb-8">
                "Interior designers are our idols. They're the daydreaming pragmatists who make real-world magic happen. They champion the power of beauty with custom, one-of-a-kind work. And they save their clients time and money by getting it all right on the first try."
              </p>
              <cite className="label-text text-[#9a7c5f] not-italic">— Schumacher</cite>
            </blockquote>
            <div className="w-px h-16 bg-[#d4c4b0] mx-auto mt-10" />
          </AnimateSection>
        </div>
      </section>

      {/* ─── TESTIMONIALS ──────────────────────────────────────────── */}
      <section className="section-pad bg-[#f7f3ee]">
        <div className="container max-w-4xl mx-auto">
          <AnimateSection>
            <p className="label-text text-[#9a7c5f] mb-12 text-center">Client Stories</p>
            <div className="relative">
              <div className="w-12 h-px bg-[#9a7c5f] mb-8" />
              <blockquote>
                <p className="font-accent italic text-[clamp(1.15rem,2.5vw,1.65rem)] text-[#2c2420] leading-relaxed mb-8">
                  &ldquo;Having Dee manage our extensive remodel was the best decision that we made! She was so very organized and had all the right contacts that kept our job running smoothly in a timely manner&hellip;which isn&rsquo;t always the case here in Maui. She provides much expertise, but also listens to her clients so that the end product reflects their desires. Whether your project is big or small, you won&rsquo;t go wrong working with Dee!&rdquo;
                </p>
                <footer className="flex items-center gap-4">
                  <div className="w-8 h-px bg-[#9a7c5f]" />
                  <cite className="not-italic">
                    <span className="font-display text-[1rem] text-[#2c2420] tracking-wide">Melodie Petry</span>
                    <span className="font-body text-[0.75rem] text-[#9a7c5f] tracking-[0.12em] uppercase ml-3">Client</span>
                  </cite>
                </footer>
              </blockquote>
            </div>
          </AnimateSection>
        </div>
      </section>

      {/* ─── FINAL CTA ────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={BEDROOM_IMG} alt="Luxury Maui bedroom" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[rgba(26,22,18,0.85)] via-[rgba(26,22,18,0.65)] to-[rgba(26,22,18,0.3)]" />
        </div>
        <div className="relative container section-pad">
          <AnimateSection className="max-w-2xl">
            <p className="label-text text-[#9a7c5f] mb-6">Ready to Begin?</p>
            <h2 className="font-display text-[clamp(2.2rem,5vw,4rem)] leading-[1.1] text-[#f7f3ee] mb-8">
              Your sanctuary<br />
              <em>is waiting.</em>
            </h2>
            <p className="font-body font-light text-[1.05rem] text-[rgba(250,248,245,0.75)] leading-relaxed mb-10 max-w-lg">
              Book a strategy session with Daruni. We'll discuss your project, your vision, and how Innerpiece can guide you from concept to the space you've always imagined.
            </p>
            <a href="https://calendly.com/daruniinnerpiece/30min" target="_blank" rel="noopener noreferrer" className="btn-primary">
              Book Your Strategy Session
            </a>
          </AnimateSection>
        </div>
      </section>

      <Footer />
    </div>
  );
}
